package com.example.buildreminder

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.medicine.R
import com.example.medicine.databinding.ActivityListBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import android.content.Intent

class List : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding
    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("SetTextI18n", "SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = getSharedPreferences("MedicinePrefs", Context.MODE_PRIVATE)

        binding.btnNext2.setOnClickListener {
            val intent2 = Intent(this, Out::class.java)
            startActivity(intent2)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val medicineCount = sharedPreferences.getInt("medicineCount", 0)
        val medicines = StringBuilder()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm")

        for (i in 0 until medicineCount) {
            val title = sharedPreferences.getString("title_$i", "Unknown Title")
            val message = sharedPreferences.getString("message_$i", "Unknown Message")
            val date = sharedPreferences.getLong("date_$i", 0L)
            val formattedDate = dateFormat.format(Date(date))

            medicines.append("Medicine: $title\nDose: $message\nTime: $formattedDate\n\n")
        }

        binding.textView2.text = medicines.toString()


        val calendar = Calendar.getInstance()
        binding.calendarView.date = calendar.timeInMillis
    }
}