package com.example.buildreminder

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.medicine.R
import com.example.medicine.databinding.ActivityListBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

class List : AppCompatActivity() {
    private lateinit var binding: ActivityListBinding

    @SuppressLint("SetTextI18n", "SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Retrieve the data from the intent
        val title = intent.getStringExtra("title")
        val message = intent.getStringExtra("message")
        val date = intent.getLongExtra("date", 0L)

        // Format the date
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm")
        val formattedDate = dateFormat.format(Date(date))

        // Display the data
        binding.textView2.text = "Medicine: $title\nDose: $message\nTime: $formattedDate"

        // Set calendar date to today
        val calendar = Calendar.getInstance()
        binding.calendarView.date = calendar.timeInMillis
    }
}